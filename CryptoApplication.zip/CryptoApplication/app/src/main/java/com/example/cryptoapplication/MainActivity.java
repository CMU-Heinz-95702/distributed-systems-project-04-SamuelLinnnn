package com.example.cryptoapplication;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


//import com.android.volley.RequestQueue;
//import com.android.volley.VolleyError;
//import com.android.volley.toolbox.JsonObjectRequest;
//import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Author: Yingyuan Lin (yingyual)
 * Last Modified: 11/21/2024
 *
 * This Android activity allows users to fetch and display cryptocurrency prices using a REST API.
 * The user enters the name of a cryptocurrency, and the app sends a POST request to the server.
 * The price data is retrieved and displayed in a new activity.
 *
 * Citation: ChatGPT helps to fetch the response data from the Web Service
 */
public class MainActivity extends AppCompatActivity {

    private static final String API_KEY = "CG-GaJREzBay4r4CvR4fxmitMxL";
    private EditText editTextCryptoName;
    private Button buttonFetchPrice;
    private TextView textViewCryptoPrice;
    private ImageView imageViewLogo;

    /**
     * Initializes the activity, sets up view bindings, and defines button click behavior.
     *
     * @param savedInstanceState the saved state of the application (if any)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find views by ID
        editTextCryptoName = findViewById(R.id.editTextCryptoName);
        buttonFetchPrice = findViewById(R.id.buttonFetchPrice);
        textViewCryptoPrice = findViewById(R.id.textViewCryptoPrice);
        imageViewLogo = findViewById(R.id.imageViewLogo);

        // Set button click listener
        buttonFetchPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cryptoName = editTextCryptoName.getText().toString().toLowerCase().trim();
                if (!cryptoName.isEmpty()) {
                    fetchCryptoPrice(cryptoName);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a cryptocurrency name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Fetches the price of the specified cryptocurrency by sending a POST request to the server.
     *
     * @param cryptoName the name of the cryptocurrency
     */
    private void fetchCryptoPrice(String cryptoName) {
        //OkHttpClient client = new OkHttpClient();
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)  // Increase connect timeout
                .readTimeout(30, TimeUnit.SECONDS)     // Increase read timeout
                .writeTimeout(30, TimeUnit.SECONDS)    // Increase write timeout
                .build();
        // Update URL to your local servlet endpoint
        //String url = "http://10.0.2.2:8080/Project4Task2_war_exploded/api/crypto";
        String url = "http://supreme-zebra-9v64997vjqwfvw5-8080.app.github.dev/api/crypto";
        // Prepare JSON request body
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("cryptoName", cryptoName);
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }

        RequestBody body = RequestBody.create(jsonObject.toString(), MediaType.parse("application/json"));

        // Create request
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/json")
                .build();

        new Thread(() -> {
            try {
                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String responseData = response.body().string();

                    try {
                        // Parse the response JSON
                        JSONObject responseJson = new JSONObject(responseData);
                        double price = responseJson.getDouble("price");

                        runOnUiThread(() -> {
                            // Start a new activity to display the price
                            Intent intent = new Intent(MainActivity.this, CryptoPriceActivity.class);
                            intent.putExtra("cryptoName", cryptoName);
                            intent.putExtra("price", String.valueOf(price));
                            startActivity(intent);
                        });
                    } catch (JSONException e) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error parsing response", Toast.LENGTH_SHORT).show());
                        e.printStackTrace();
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error: " + response.code() + " " + response.message(), Toast.LENGTH_SHORT).show());
                }
            } catch (IOException e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show());
                e.printStackTrace();
            }
        }).start();
    }

}
