package com.example.cryptoapplication;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

/**
 * Author: [Your Name]
 * Last Modified: [Current Date]
 *
 * This activity displays the price of a cryptocurrency fetched from the server.
 * The price is received as an intent extra from the previous activity.
 * The user can return to the main screen using the back button.
 */
public class CryptoPriceActivity extends AppCompatActivity {

    private TextView textViewCryptoPrice;
    private Button buttonBack;

    /**
     * Initializes the activity, retrieves cryptocurrency price from intent extras, and sets up the UI.
     *
     * @param savedInstanceState the saved state of the application (if any)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crypto_price);

        // Find views by ID
        textViewCryptoPrice = findViewById(R.id.textViewCryptoPrice);
        buttonBack = findViewById(R.id.buttonBack);

        // Get the intent and extract the price data
        String cryptoPrice = getIntent().getStringExtra("price");
        String cryptoName = getIntent().getStringExtra("cryptoName");

        // Update UI with the received price
        if (cryptoPrice != null) {
            textViewCryptoPrice.setText("The price of " + cryptoName + " is: " + cryptoPrice);
        } else {
            textViewCryptoPrice.setText("Error fetching crypto price");
        }

        // Set back button listener
        buttonBack.setOnClickListener(v -> finish());

        // Set up the action bar to enable the back button
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    /**
     * Handles menu item selections. Specifically, handles the back button in the action bar.
     *
     * @param item the selected menu item
     * @return true if the back button was handled, otherwise calls the superclass implementation
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // End current activity and return to the previous one
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}



