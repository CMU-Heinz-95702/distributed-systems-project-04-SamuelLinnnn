package ds.project4task2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

/**
 * Author: Yingyuan Lin (yingyual)
 * Last Modified: 11/21/2024
 *
 * This class implements a servlet that provides cryptocurrency price data.
 * It handles both GET and POST requests, fetches data from a third-party API (CoinGecko),
 * logs request and response details to a MongoDB database, and returns the price information as JSON.
 *
 * Citation: ChatGPT helps me to code the communication part between the this project and the android studio.
 * It also helps to handle the CoinGecko API request and parse the response data.
 */

public class CryptoServlet extends HttpServlet {
    private static final String API_KEY = "CG-GaJREzBay4r4CvR4fxmitMxL";


    /**
     * Handles POST requests by forwarding them to the handleRequest method.
     *
     * @param request  the HttpServletRequest object
     * @param response the HttpServletResponse object
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        handleRequest(request, response);
    }

    /**
     * Handles GET requests to fetch cryptocurrency prices.
     * Verifies the presence of the 'cryptoName' parameter and forwards the request to the handleRequest method.
     *
     * @param request  the HttpServletRequest object
     * @param response the HttpServletResponse object
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cryptoName = request.getParameter("cryptoName");
        if (cryptoName == null || cryptoName.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing or empty 'cryptoName'");
            return;
        }

    }


    /**
     * Processes the request by fetching cryptocurrency data from a third-party API, logging the request details,
     * and responding with the price data in JSON format.
     *
     * @param request  the HttpServletRequest object
     * @param response the HttpServletResponse object
     * @throws IOException if an I/O error occurs
     */
    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        long startTime = System.currentTimeMillis();
        // Parsing input from mobile app (assumed as JSON)
        StringBuilder requestBody = new StringBuilder();
        try (BufferedReader reader = request.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                requestBody.append(line);
            }
        }

        System.out.println("Request body: " + requestBody.toString());

        String cryptoName = parseCryptoName(requestBody.toString());
        if (cryptoName == null || cryptoName.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing or empty 'cryptoName'");
            return;
        }

        // Fetch data from third-party API (CoinGecko)
        String thirdPartyResponse = fetchCryptoPrice(cryptoName);
        if (thirdPartyResponse == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Failed to fetch data from third-party API");
            return;
        }

        double price;
        try {
            price = parsePriceFromResponse(thirdPartyResponse, cryptoName);
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to parse third-party API response");
            return;
        }

        // Log request/response details to MongoDB using the helper class
        Document logEntry = new Document()
                .append("timestamp", LocalDateTime.now().toString())
                .append("cryptoName", cryptoName)
                .append("userAgent", request.getHeader("User-Agent"))
                .append("thirdPartyApiResponse", thirdPartyResponse)
                .append("price", price)
                .append("clientIP", request.getRemoteAddr());

        long responseTime = System.currentTimeMillis() - startTime; // Calculate response time
        MongoDB.logRequest(logEntry, responseTime); // Pass response time to logRequest
        // Reply to mobile app
        String jsonResponse = String.format("{\"cryptoName\": \"%s\", \"price\": %f}", cryptoName, price);
        try (PrintWriter out = response.getWriter()) {
            out.print(jsonResponse);
            out.flush();
        }
    }

    /**
     * Extracts the cryptocurrency name from the request body JSON.
     *
     * @param requestBody the raw JSON string from the request body
     * @return the extracted cryptocurrency name, or null if not found
     */
    private String parseCryptoName(String requestBody) {
        // Basic JSON parsing to extract cryptoName
        if (requestBody.contains("\"cryptoName\":")) {
            int startIndex = requestBody.indexOf("\"cryptoName\":") + 14;
            int endIndex = requestBody.indexOf('"', startIndex);
            if (startIndex >= 0 && endIndex > startIndex) {
                return requestBody.substring(startIndex, endIndex);
            }
        }
        return null;
    }

    /**
     * Fetches cryptocurrency price data from a third-party API (CoinGecko).
     *
     * @param cryptoName the name of the cryptocurrency to fetch data for
     * @return the raw JSON response from the third-party API, or null if the fetch fails
     */
    private String fetchCryptoPrice(String cryptoName) {
        String thirdPartyApiUrl = "https://api.coingecko.com/api/v3/simple/price?ids=" + cryptoName + "&vs_currencies=usd";
        StringBuilder apiResponse = new StringBuilder();

        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(thirdPartyApiUrl).openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("accept", "application/json");
            conn.setRequestProperty("x-cg-demo-api-key", API_KEY);

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        apiResponse.append(line);
                    }
                }
                return apiResponse.toString();
            } else {
                System.err.println("Failed to fetch data from third-party API. Response Code: " + responseCode);
                return null;
            }
        } catch (IOException e) {
            System.err.println("Error occurred while fetching data from third-party API: " + e.getMessage());
            return null;
        }
    }

    /**
     * Parses the price of a cryptocurrency from the third-party API response.
     *
     * @param response the raw JSON response from the third-party API
     * @param cryptoName the name of the cryptocurrency
     * @return the parsed price as a double
     * @throws RuntimeException if parsing fails
     */
    private double parsePriceFromResponse(String response, String cryptoName) {
        if (response.contains(cryptoName) && response.contains("usd")) {
            int startIndex = response.indexOf("\"usd\":") + 6;
            int endIndex = response.indexOf('}', startIndex);
            if (startIndex >= 0 && endIndex > startIndex) {
                return Double.parseDouble(response.substring(startIndex, endIndex));
            }
        }
        throw new RuntimeException("Failed to parse price from response");
    }
}
