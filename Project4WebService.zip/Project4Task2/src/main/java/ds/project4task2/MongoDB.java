package ds.project4task2;

// MongoDBHelper.java (Helper class for MongoDB operations

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Author: Yingyuan Lin (yingyual)
 * Last Modified: 11/21/2024
 *
 * This class provides functionality to interact with a MongoDB database for logging and analytics purposes.
 * It connects to the database, manages collections for logging requests and storing analytics,
 * and provides methods to retrieve logs, fetch analytics, and update analytics with new request data.
 *
 * Citation: GPT helps me to code the retrieval of log data in MongoDB and code the log data analysis part
 */
public class MongoDB {
    private static final String MONGO_URI = "mongodb+srv://yingyual:1652043681aA@cluster0.jk5a5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
    private static MongoClient mongoClient;
    private static MongoDatabase database;
    private static MongoCollection<Document> logCollection;
    private static MongoCollection<Document> analyticsCollection;

    static {
        try {
            // Initialize MongoDB client with specified settings
            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(new ConnectionString(MONGO_URI))
                    .applyToSocketSettings(builder -> builder.connectTimeout(10, TimeUnit.SECONDS)) // Set a reasonable timeout
                    .build();
            mongoClient = MongoClients.create(settings);

            database = mongoClient.getDatabase("CryptoServiceLogs");
            logCollection = database.getCollection("logs");
            analyticsCollection = database.getCollection("analytics");
            initializeAnalytics();
        } catch (Exception e) {
            System.err.println("Failed to connect to MongoDB: " + e.getMessage());
        }
    }

    /**
     * Initializes the analytics document in the analytics collection with default values if it doesn't already exist.
     */
    private static void initializeAnalytics() {
        if (analyticsCollection.countDocuments(Filters.eq("_id", "analytics")) == 0) {
            Document initialAnalytics = new Document()
                    .append("_id", "analytics")  // Add an _id field to easily find this document
                    .append("topRequestedCryptos", new Document())
                    .append("totalRequests", 0)
                    .append("totalResponseTime", 0L)
                    .append("topRequestingIPs", new Document());
            analyticsCollection.insertOne(initialAnalytics);
        }
    }

    /**
     * Retrieves all log entries from the logs collection.
     *
     * @return a list of all log documents
     */
    public static List<Document> getAllLogs() {
        return logCollection.find().into(new ArrayList<>());
    }

    /**
     * Retrieves the analytics document from the analytics collection.
     *
     * @return the analytics document
     */
    public static Document getAnalytics() {
        return analyticsCollection.find(Filters.eq("_id", "analytics")).first();
    }

    /**
     * Logs a request by inserting a log entry into the logs collection
     * and updating analytics data with the request details.
     *
     * @param logEntry the log document containing request details
     * @param responseTime the response time for the request in milliseconds
     */
    public static void logRequest(Document logEntry, long responseTime) {
        logCollection.insertOne(logEntry);
        updateAnalytics(logEntry, responseTime);
    }

    /**
     * Updates the analytics document with data from a new request.
     * Updates include incrementing cryptocurrency request counts, total requests, total response time,
     * and request counts for client IPs.
     *
     * @param logEntry the log document containing request details
     * @param responseTime the response time for the request in milliseconds
     */
    private static void updateAnalytics(Document logEntry, long responseTime) {
        String cryptoName = logEntry.getString("cryptoName");
        String clientIP = logEntry.getString("clientIP");

        // Instead of altering the IP address format, store the IP as-is.
        // Update top requested cryptocurrencies
        analyticsCollection.updateOne(
                Filters.eq("_id", "analytics"),
                Updates.inc("topRequestedCryptos." + cryptoName, 1),
                new com.mongodb.client.model.UpdateOptions().upsert(true)
        );

        // Update total requests and total response time
        analyticsCollection.updateOne(
                Filters.eq("_id", "analytics"),
                Updates.inc("totalRequests", 1)
        );
        analyticsCollection.updateOne(
                Filters.eq("_id", "analytics"),
                Updates.inc("totalResponseTime", responseTime)
        );

        // Update top requesting IPs without modifying it
        analyticsCollection.updateOne(
                Filters.eq("_id", "analytics"),
                Updates.inc("topRequestingIPs." + clientIP, 1),
                new com.mongodb.client.model.UpdateOptions().upsert(true)
        );
    }

}